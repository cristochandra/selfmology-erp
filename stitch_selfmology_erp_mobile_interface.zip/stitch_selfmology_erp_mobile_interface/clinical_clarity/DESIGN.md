---
name: Clinical Clarity
colors:
  surface: '#fff8f3'
  surface-dim: '#e4d8c9'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fef2e2'
  surface-container: '#f9ecdc'
  surface-container-high: '#f3e6d7'
  surface-container-highest: '#ede1d1'
  on-surface: '#201b11'
  on-surface-variant: '#504533'
  inverse-surface: '#362f25'
  inverse-on-surface: '#fbefdf'
  outline: '#827561'
  outline-variant: '#d5c4ac'
  surface-tint: '#7c5800'
  primary: '#7c5800'
  on-primary: '#ffffff'
  primary-container: '#fdba21'
  on-primary-container: '#6c4c00'
  inverse-primary: '#febb22'
  secondary: '#006a6a'
  on-secondary: '#ffffff'
  secondary-container: '#90efef'
  on-secondary-container: '#006e6e'
  tertiary: '#006e0a'
  on-tertiary: '#ffffff'
  tertiary-container: '#4ce245'
  on-tertiary-container: '#006008'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdea7'
  primary-fixed-dim: '#febb22'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#93f2f2'
  secondary-fixed-dim: '#76d6d5'
  on-secondary-fixed: '#002020'
  on-secondary-fixed-variant: '#004f4f'
  tertiary-fixed: '#75ff68'
  tertiary-fixed-dim: '#4ce346'
  on-tertiary-fixed: '#002201'
  on-tertiary-fixed-variant: '#005306'
  background: '#fff8f3'
  on-background: '#201b11'
  surface-variant: '#ede1d1'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  margin-edge: 20px
  gutter: 12px
  card-padding: 16px
  section-gap: 24px
---

## Brand & Style

The design system is anchored in a "Clinical Clarity" aesthetic—a fusion of high-end dermatological precision and modern enterprise efficiency. The brand personality is authoritative yet accessible, evoking a sense of cleanliness, expertise, and technological sophistication. 

The style utilizes a **Modern Minimalist** approach with subtle **Material Design 3** influences. It prioritizes high-order information architecture, using expansive white space to reduce cognitive load for practitioners managing complex skincare data. The emotional response is intended to be "calmly productive," moving away from the cluttered look of traditional ERPs toward a refined, lab-inspired interface.

## Colors

This design system employs a high-contrast palette to distinguish between clinical data and interactive actions. 

- **Primary Action:** Mustard/Sunflower Yellow (#FDBA21) is reserved exclusively for primary calls-to-action, buttons, and critical progress indicators. Its warmth breaks the "cold" clinical feel while maintaining high visibility.
- **Semantic Status:** A dual-green system is used for status tracking. Mint/Teal Green denotes "Active" or "Standard" clinical states, while Spring/Lime Green signifies "New," "Healthy," or "Positive Outcome" status.
- **Surface Architecture:** The system uses Pure White (#FFFFFF) for primary interactive cards and a soft cool off-white (#F5F5F7) for the base application background to provide subtle depth without traditional heavy borders.

## Typography

The design system utilizes **Inter** for its exceptional legibility in data-heavy environments. The typographic scale is optimized for Android mobile devices, emphasizing a clear hierarchy.

Headlines use tighter letter spacing and heavier weights to create a "geometric" anchor for page sections. Labels and small metadata utilize a slightly increased letter spacing and uppercase styling to mimic medical labeling and ensure quick scanning of patient records or inventory SKUs.

## Layout & Spacing

Following Material Design 3 logic, the layout is mobile-first and fluid. It employs an 8dp grid system to maintain vertical rhythm. 

The standard layout uses a 20px safe margin from the device edges. Content is organized into a single-column stack on mobile, using "Section Gaps" (24px) to separate distinct clinical modules (e.g., Patient History vs. Active Prescriptions). Card internal padding is strictly 16px to ensure touch targets remain comfortable while preserving the minimalist aesthetic.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Ambient Shadows**. 

The base layer is the soft off-white surface. Cards sit at a low elevation (Level 1) using a highly diffused, low-opacity shadow (`rgba(0,0,0,0.04)`) with a 4px blur. When a card is active or pressed, it lifts to Level 2 with a slightly more pronounced shadow. 

This design system avoids heavy inner shadows or gradients. Depth is primarily communicated through the contrast between the white card surfaces and the cool-grey background, creating a "stacked sheet" appearance typical of medical charts.

## Shapes

The shape language is "Softly Geometric." Primary cards and input containers use a 0.5rem (8px) corner radius to feel professional and structured. 

Buttons and Chips utilize a more pronounced "Pill-shaped" or `rounded-xl` (24px) radius to distinguish interactive elements from information-display containers. This contrast helps the user instinctively identify what can be tapped versus what is purely for reading.

## Components

- **Buttons:** Primary buttons are Solid Mustard (#FDBA21) with black text for maximum contrast. Secondary buttons are outlined in a thin 1px stroke of the neutral-muted shade.
- **Cards:** Clean white containers with no visible borders, utilizing the 4px ambient shadow. Card headers should use `title-sm` typography.
- **Chips/Tags:** Used for "Skin Type" or "Product Status." These utilize low-opacity versions of the Mint and Lime greens with high-saturation text of the same hue to keep the interface feeling light.
- **Input Fields:** Material-style "Filled" containers using the background-soft color, with a 2px bottom indicator that turns Mustard on focus. 
- **Lists:** Clean rows with 1px hairline dividers (#E5E5E7). Each row has a minimum height of 56px to ensure Android accessibility standards.
- **Clinical Components:** Specific additions include "Dosage Progress Bars" (Mustard) and "Ingredient Bio-tags" (Mint Green) to accommodate the skincare ERP niche.